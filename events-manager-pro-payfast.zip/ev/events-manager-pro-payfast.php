<?php
/*
Plugin Name: Events Manager Pro - PayFast Gateway
Plugin URI: http://wp-events-plugin.com
Description: PayFast gateway add-on for Events Manager Pro
Version: 1.0
Depends: Events Manager Pro
Author: PayFast
Author URI: http://www.payfast.co.za
Copyright (c) 2008 PayFast (Pty) Ltd
You (being anyone who is not PayFast (Pty) Ltd) may download and use this plugin / code in your own website in conjunction with a registered and active PayFast account. If your PayFast account is terminated for any reason, you may not use this plugin / code or part thereof.
Except as expressly indicated in this licence, you may not use, copy, modify or distribute this plugin / code or part thereof in any way.
*/
	
function em_pro_gateway_payfast_init() {
	//add-ons
	include('gateway.payfast.php');
}
//Set when to run the plugin : after EM is loaded.
add_action( 'plugins_loaded', 'em_pro_gateway_payfast_init', 100 );
	
function em_pro_gateway_payfast_currency($currencies){
	$currencies->names['ZAR'] = 'ZAR - South African Rand'; //textual representation of the currency
	$currencies->symbols['ZAR'] = 'ZAR'; //If the symbol requires an entity, like for � it's &euro;
	$currencies->true_symbols['ZAR'] = 'R'; //The actual symbol used, e.g. for Euros it's �
	return $currencies;
}
//add the ZAR currency to EM
add_filter('em_get_currencies','em_pro_gateway_payfast_currency');